package com.codingwithjks.kotlinflow.Network

object Url {
    const val baseUrl="https://jsonplaceholder.typicode.com/"
}