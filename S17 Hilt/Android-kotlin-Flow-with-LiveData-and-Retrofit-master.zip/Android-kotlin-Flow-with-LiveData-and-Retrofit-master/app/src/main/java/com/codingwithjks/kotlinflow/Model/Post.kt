package com.codingwithjks.kotlinflow.Model

data class Post(val body:String) {
}