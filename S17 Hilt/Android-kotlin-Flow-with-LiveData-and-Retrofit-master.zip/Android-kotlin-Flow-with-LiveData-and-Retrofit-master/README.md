# Android-kotlin-Flow-with-LiveData-and-Retrofit

In this project we will make a simple project with the help of Kotlin Flow api with LiveData and Retrofit ,where we will fetch some data from the server and shows into RecyclerView.
